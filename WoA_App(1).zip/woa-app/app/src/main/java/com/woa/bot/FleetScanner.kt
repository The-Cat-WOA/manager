package com.woa.bot

import android.content.Context
import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Rect

/**
 * Liest "Meine Flotte" im Spiel aus: scrollt die Kartenreihe seitlich durch, erkennt pro Karte
 * Kennzeichen, Flughafen, Typ und Spielername per Texterkennung und merkt sich jedes Kennzeichen nur einmal.
 */
class FleetScanner(private val ctx: Context, private val grab: () -> Mat?) {

    @Volatile
    var stop = false

    private class Line(val t: String, val raw: String, val cx: Int, val left: Int)

    private val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val regRe = Regex("^[A-Z0-9]{1,2}-[A-Z0-9]{2,5}$")      // z.B. B-HHNJ, D-AIXA
    private val apRe = Regex("^[A-Z]{3,4}$")                          // Flughafen: NGO, BOH
    private val typeRe = Regex("^(?=.*[0-9])[A-Z0-9-]{3,8}$")         // Typ: E290, A21NY, B77W
    private val found = LinkedHashMap<String, JSONObject>()

    private fun pause(ms: Long) {
        var left = ms
        while (left > 0 && !stop) {
            Thread.sleep(minOf(left, 50L))
            left -= 50
        }
    }

    private fun swipe(forward: Boolean) {
        val f = grab() ?: return
        val w = f.cols().toFloat()
        val y = f.rows() * 0.55f
        val svc = TapService.instance ?: throw IllegalStateException(ctx.getString(R.string.log_no_acc))
        if (forward) svc.drag(w * 0.85f, y, w * 0.15f, y, 900) else svc.drag(w * 0.15f, y, w * 0.85f, y, 500)
    }

    /** Ein Bild auswerten; gibt die Anzahl NEUER Flugzeuge zurueck. */
    private fun scanOnce(): Int {
        val f = grab() ?: return 0
        val w = f.cols()
        val h = f.rows()
        val y0 = (h * 0.225).toInt()
        val y1 = (h * 0.335).toInt()
        val band = Mat(f, Rect(0, y0, w, y1 - y0))
        val bmp = Bitmap.createBitmap(band.cols(), band.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(band, bmp)
        val text = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
        bmp.recycle()

        val lines = ArrayList<Line>()
        for (block in text.textBlocks) for (l in block.lines) {
            val b = l.boundingBox ?: continue
            lines.add(Line(l.text.trim().uppercase().replace(" ", ""), l.text.trim(), b.centerX(), b.left))
        }
        var added = 0
        for (r in lines.filter { regRe.matches(it.t) }) {
            if (found.containsKey(r.t)) continue                       // schon bekannt -> nicht nochmal
            val from = r.left - (w * 0.01).toInt()
            val to = r.left + (w * 0.175).toInt()
            val card = lines.filter { it !== r && it.cx in from..to }
            val airport = card.firstOrNull { apRe.matches(it.t) }?.t ?: ""
            val type = card.firstOrNull { typeRe.matches(it.t) }?.t ?: ""
            val player = card.filter { !apRe.matches(it.t) && !typeRe.matches(it.t) }
                .maxByOrNull { it.left }?.raw ?: ""
            found[r.t] = JSONObject().put("registration", r.t).put("type", type)
                .put("airport", airport).put("player", player)
            Bus.log(ctx.getString(R.string.log_scan_new, r.t, type, airport))
            added++
        }
        return added
    }

    fun run() {
        Bus.running = true
        Bus.status = ctx.getString(R.string.st_scan)
        Bus.log(ctx.getString(R.string.log_scan_start))
        try {
            repeat(5) { if (!stop) { swipe(false); pause(400) } }      // erst ganz nach links
            var idle = 0
            var rounds = 0
            while (!stop && rounds < 80 && idle < 2) {
                pause(1000)                                             // Scrollen ausklingen lassen
                if (scanOnce() == 0) idle++ else idle = 0
                Bus.open = found.size
                swipe(true)
                rounds++
            }
            Bus.scanJson = JSONArray(found.values.toList()).toString()
            Bus.log(ctx.getString(R.string.log_scan_done, found.size))
        } catch (e: Exception) {
            Bus.log(ctx.getString(R.string.log_error, e.message ?: e.toString()))
        } finally {
            Bus.status = ""
            Bus.running = false
        }
    }
}
