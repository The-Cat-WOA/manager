package com.woa.bot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Einfache Oberflaeche ohne Layout-XML (weniger Fehlerquellen). Querformat. */
class MainActivity : Activity() {

    private val bg = Color.parseColor("#0F0F12")
    private val card = Color.parseColor("#1A1A1F")
    private val acc = Color.parseColor("#E5333A")
    private val txt = Color.parseColor("#F5F5F7")
    private val muted = Color.parseColor("#8A8A93")

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var statusView: TextView
    private lateinit var statsView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private var lastSig = ""

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 12): GradientDrawable {
        val d = GradientDrawable()
        d.cornerRadius = dp(radius).toFloat()
        d.setColor(color)
        return d
    }

    private fun button(text: String, color: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.background = rounded(color)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        lp.topMargin = dp(8)
        b.layoutParams = lp
        return b
    }

    private fun toggle(text: String, key: String, default: Boolean): Switch {
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val s = Switch(this)
        s.text = text
        s.setTextColor(txt)
        s.textSize = 13f
        s.isChecked = prefs.getBoolean(key, default)
        s.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        s.layoutParams = lp
        return s
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(bg)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(bg)
        root.setPadding(dp(18), dp(12), dp(18), dp(12))

        // ---- links: Steuerung
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = getString(R.string.title)
        title.setTextColor(txt)
        title.textSize = 26f
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        left.addView(title)
        statusView = TextView(this)
        statusView.setTextColor(acc)
        statusView.textSize = 14f
        left.addView(statusView)
        statsView = TextView(this)
        statsView.setTextColor(txt)
        statsView.textSize = 13f
        statsView.setPadding(0, dp(6), 0, dp(4))
        left.addView(statsView)
        left.addView(button(getString(R.string.btn_acc), Color.parseColor("#2A2A31")) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        startBtn = button(getString(R.string.btn_start), acc) { startBot() }
        left.addView(startBtn)
        stopBtn = button(getString(R.string.btn_stop), Color.parseColor("#2A2A31")) { stopBot() }
        left.addView(stopBtn)
        left.addView(button(getString(R.string.btn_scan), Color.parseColor("#2A2A31")) { startScan() })
        left.addView(button(getString(R.string.btn_fleet), Color.parseColor("#2A2A31")) {
            startActivity(Intent(this, FleetActivity::class.java))
        })
        left.addView(toggle(getString(R.string.sw_ramp), "ramp", true))
        left.addView(toggle(getString(R.string.sw_xp), "claim", true))
        left.addView(toggle(getString(R.string.sw_maint), "maint", true))
        left.addView(toggle(getString(R.string.sw_yellow), "yellow", true))
        val hint = TextView(this)
        hint.text = getString(R.string.hint)
        hint.setTextColor(muted)
        hint.textSize = 12f
        hint.setPadding(0, dp(12), 0, 0)
        left.addView(hint)

        val leftScroll = ScrollView(this)
        leftScroll.addView(left)
        root.addView(leftScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // ---- rechts: Log
        logView = TextView(this)
        logView.setTextColor(Color.parseColor("#C9C9D1"))
        logView.textSize = 12f
        logView.typeface = android.graphics.Typeface.MONOSPACE
        logView.setPadding(dp(12), dp(10), dp(12), dp(10))
        logScroll = ScrollView(this)
        logScroll.background = rounded(card, 14)
        logScroll.addView(logView)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.4f)
        lp.leftMargin = dp(16)
        root.addView(logScroll, lp)

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun startBot() {
        if (Bus.running) return
        if (TapService.instance == null) {
            Toast.makeText(this, R.string.toast_acc, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    private fun startScan() {
        if (Bus.running) return
        if (TapService.instance == null) {
            Toast.makeText(this, R.string.toast_acc, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode == 1 || requestCode == 2) && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BotService::class.java)
                .setAction(BotService.ACTION_START)
                .putExtra(BotService.EXTRA_CODE, resultCode)
                .putExtra(BotService.EXTRA_DATA, data)
                .putExtra(BotService.EXTRA_SCAN, requestCode == 2)
            startForegroundService(i)
            Bus.running = true
            moveTaskToBack(true)            // Spiel soll sichtbar werden
        }
    }

    private fun stopBot() {
        startService(Intent(this, BotService::class.java).setAction(BotService.ACTION_STOP))
    }

    private fun refresh() {
        val running = Bus.running
        statusView.text = if (running) {
            if (Bus.status.isEmpty()) getString(R.string.status_running) else Bus.status
        } else getString(R.string.status_idle)
        statsView.text = getString(R.string.stats_fmt, Bus.assigned, Bus.claimed, Bus.maint, Bus.open, Bus.skipped)
        startBtn.alpha = if (running) 0.4f else 1f
        stopBtn.alpha = if (running) 1f else 0.4f

        val lines = Bus.snapshot()
        val sig = lines.size.toString() + (lines.lastOrNull() ?: "")
        if (sig != lastSig) {
            lastSig = sig
            logView.text = lines.joinToString("\n")
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }
}
