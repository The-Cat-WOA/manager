package com.woa.bot

import android.content.Context
import org.opencv.core.Mat
import kotlin.math.abs
import kotlin.math.min

/** Gemeinsamer Zustand zwischen Dienst und Oberflaeche. */
object Bus {
    private val lines = ArrayList<String>()
    @Volatile var running = false
    @Volatile var assigned = 0
    @Volatile var claimed = 0
    @Volatile var maint = 0
    @Volatile var open = 0
    @Volatile var skipped = 0
    @Volatile var status = ""
    @Volatile var scanJson: String? = null

    fun log(msg: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        synchronized(lines) {
            lines.add("$t  $msg")
            if (lines.size > 300) lines.removeAt(0)
        }
    }

    fun snapshot(): List<String> = synchronized(lines) { ArrayList(lines) }

    fun reset() {
        assigned = 0; claimed = 0; maint = 0; open = 0; skipped = 0; status = ""
    }
}

class BotCfg(val ramp: Boolean, val claim: Boolean, val maint: Boolean, val popupYellow: Boolean)

/** Der Bot-Ablauf (Port von woa_bot.py). Laeuft in einem eigenen Thread. */
class BotCore(
    private val ctx: Context,
    private val grab: () -> Mat?,
    private val cfg: BotCfg
) {
    private class StopEx : RuntimeException()

    private val v = Vision(ctx)
    private var scale = 1.0
    private var calibrated = false
    private var lastCalib = 0L
    private val ignore = HashMap<Int, Long>()

    @Volatile
    var stop = false

    private fun say(id: Int, vararg a: Any) = Bus.log(ctx.getString(id, *a))

    private fun wait(ms: Long) {
        var left = ms
        while (left > 0) {
            if (stop) throw StopEx()
            val d = min(left, 50L)
            Thread.sleep(d)
            left -= d
        }
        if (stop) throw StopEx()
    }

    private fun acc(): TapService {
        if (stop) throw StopEx()
        return TapService.instance ?: throw IllegalStateException(ctx.getString(R.string.log_no_acc))
    }

    private fun tap(x: Int, y: Int) { acc().tap(x.toFloat(), y.toFloat()) }

    private fun drag(a: Pt, b: Pt) { acc().drag(a.x.toFloat(), a.y.toFloat(), b.x.toFloat(), b.y.toFloat()) }

    /** Aktuelles Bild (RGBA) + Graubild. */
    private fun frame(): Pair<Mat, Mat> {
        val end = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < end) {
            val f = grab()
            if (f != null && !f.empty()) return Pair(f, v.gray(f))
            wait(100)
        }
        throw IllegalStateException(ctx.getString(R.string.log_no_capture))
    }

    private fun recalibrate(g: Mat, force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastCalib < 60_000) return
        lastCalib = now
        calibrated = true
        val (score, s) = v.calibrate(g)
        if (score >= 0.75) {
            if (abs(s - scale) > 0.01) say(R.string.log_scale, "%.2f".format(s), "%.2f".format(score))
            scale = s
        }
    }

    private fun isIgnored(y: Int): Boolean {
        val now = System.currentTimeMillis()
        val it = ignore.entries.iterator()
        var hit = false
        while (it.hasNext()) {
            val e = it.next()
            if (e.value < now) it.remove() else if (abs(y - e.key) < 25 * scale) hit = true
        }
        return hit
    }

    // ------------------------------------------------------------ Praemien-Fenster
    private fun handlePopup(rgba: Mat, g: Mat): Boolean {
        val (up, ca) = v.findPopup(rgba, g, scale)
        val target = (if (cfg.popupYellow) up else ca) ?: return false
        tap(target.x, target.y)
        say(if (cfg.popupYellow) R.string.log_popup_yellow else R.string.log_popup_cancel)
        wait(1200)
        return true
    }

    // ------------------------------------------------------------ XP einsammeln
    private fun claim(row: Row): Boolean {
        val s = scale
        tap((row.x + 65 * s).toInt(), (row.y - 37 * s).toInt())
        wait(800)
        var btn: Pt? = null
        var end = System.currentTimeMillis() + 1800
        while (System.currentTimeMillis() < end) {
            val (rgba, g) = frame()
            btn = v.findClaimButton(rgba, g, s)
            if (btn != null) break
            wait(200)
        }
        val b = btn
        if (b == null) {
            say(R.string.log_claim_missing)
            return false
        }
        tap(b.x, b.y)
        wait(1000)
        end = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < end) {
            val (rgba, g) = frame()
            if (handlePopup(rgba, g)) return true
            wait(250)
        }
        say(R.string.log_popup_missing)
        return true
    }

    // ------------------------------------------------------------ Wartung
    /** Zeile anklicken, "Zur Wartung senden" druecken, danach ein zweites Mal (Bestaetigung). */
    private fun maintain(row: Row): Boolean {
        val s = scale
        tap((row.x + 65 * s).toInt(), (row.y - 37 * s).toInt())
        wait(800)
        var btn: Pt? = null
        val end = System.currentTimeMillis() + 1800
        while (System.currentTimeMillis() < end) {
            val (rgba, _) = frame()
            btn = v.findYellowLeft(rgba, s)
            if (btn != null) break
            wait(200)
        }
        val b = btn
        if (b == null) {
            say(R.string.log_maint_missing)
            return false
        }
        tap(b.x, b.y)
        wait(1000)
        val (rgba2, _) = frame()
        val second = v.findYellowLeft(rgba2, s) ?: v.findPrimary(rgba2, s)
        if (second != null) {
            tap(second.x, second.y)
            wait(1200)
        }
        return true
    }

    // ------------------------------------------------------------ Crew zuweisen
    private fun process(row: Row): Boolean {
        val s = scale
        tap((row.x + 65 * s).toInt(), (row.y - 37 * s).toInt())
        wait(800)

        var anchor: Pt? = null
        val end = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < end) {
            val (_, g) = frame()
            anchor = v.findAnchor(g, s)
            if (anchor != null) break
            wait(200)
        }
        val a = anchor
        if (a == null) {
            say(R.string.log_no_panel)
            return false
        }

        drag(v.off(a, Vision.HANDLE, s), v.off(a, Vision.DRAG_TO, s))
        wait(350)
        var f = frame()

        var tries = 0
        while (v.warnPresent(f.second, a, s) && tries < 6) {
            tap(a.x, a.y)
            wait(200)
            f = frame()
            tries++
        }
        if (v.warnPresent(f.second, a, s)) {
            say(R.string.log_not_enough)
            Bus.skipped++
            return false
        }

        if (cfg.ramp && !v.toggleOn(f.first, a, s)) {
            val t = v.off(a, Vision.TOGGLE, s)
            tap(t.x, t.y)
            wait(400)
            f = frame()
            if (!v.toggleOn(f.first, a, s)) {
                say(R.string.log_ramp_fail)
                Bus.skipped++
                return false
            }
            if (v.warnPresent(f.second, a, s)) {
                say(R.string.log_ramp_after)
                Bus.skipped++
                return false
            }
        }

        if (!v.buttonBright(f.first, a, s)) {
            say(R.string.log_btn_inactive)
            return false
        }
        val b = v.off(a, Vision.BUTTON, s)
        tap(b.x, b.y)
        wait(1200)
        return true
    }

    // ------------------------------------------------------------ Hauptschleife
    private enum class Kind { CLAIM, MAINT, ASSIGN }

    fun run() {
        var fail = 0
        Bus.running = true
        say(R.string.log_started)
        try {
            while (!stop) {
                Bus.status = ctx.getString(R.string.st_search)
                val (rgba, g) = frame()
                if (!calibrated) recalibrate(g, true)
                if (cfg.claim && handlePopup(rgba, g)) continue
                recalibrate(g, false)

                val assigns = v.findPlanes(rgba, g, scale)
                val claims = if (cfg.claim) v.findClaims(rgba, g, scale).filter { !isIgnored(it.y) } else emptyList()
                val maints = if (cfg.maint) v.findMaint(rgba, g, scale).filter { !isIgnored(it.y) } else emptyList()
                Bus.open = assigns.size
                val cands = claims.map { Pair(Kind.CLAIM, it) } +
                    maints.map { Pair(Kind.MAINT, it) } +
                    assigns.map { Pair(Kind.ASSIGN, it) }
                if (cands.isEmpty()) {
                    fail = 0
                    Bus.status = ctx.getString(R.string.st_none)
                    wait(1000)
                    continue
                }

                val n = fail % cands.size
                val (kind, row) = cands[n]
                when (kind) {
                    Kind.CLAIM -> {
                        Bus.status = ctx.getString(R.string.st_claim, n + 1, cands.size)
                        say(R.string.log_open_claim, cands.size, n + 1)
                    }
                    Kind.MAINT -> {
                        Bus.status = ctx.getString(R.string.st_maint, n + 1, cands.size)
                        say(R.string.log_open_maint, cands.size, n + 1)
                    }
                    Kind.ASSIGN -> {
                        Bus.status = ctx.getString(R.string.st_work, n + 1, cands.size)
                        say(R.string.log_open_assign, cands.size, n + 1)
                    }
                }

                var ok = false
                when (kind) {
                    Kind.CLAIM -> {
                        ok = claim(row)
                        ignore[row.y] = System.currentTimeMillis() + (if (ok) 6000L else 10000L)
                        if (ok) {
                            Bus.claimed++
                            say(R.string.log_ok_claim, Bus.claimed)
                        }
                    }
                    Kind.MAINT -> {
                        ok = maintain(row)
                        ignore[row.y] = System.currentTimeMillis() + (if (ok) 8000L else 12000L)
                        if (ok) {
                            Bus.maint++
                            say(R.string.log_ok_maint, Bus.maint)
                        }
                    }
                    Kind.ASSIGN -> {
                        ok = process(row)
                        if (ok) {
                            Bus.assigned++
                            say(R.string.log_ok_assign, Bus.assigned)
                        }
                    }
                }

                if (ok) {
                    fail = 0
                } else {
                    fail++
                    if (fail >= cands.size) {
                        Bus.status = ctx.getString(R.string.st_wait8)
                        say(R.string.log_all_checked)
                        fail = 0
                        wait(8000)
                    }
                }
            }
        } catch (e: StopEx) {
            // normal beendet
        } catch (e: Exception) {
            Bus.log(ctx.getString(R.string.log_error, e.message ?: e.toString()))
        } finally {
            Bus.status = ""
            say(R.string.log_stopped)
            Bus.running = false
        }
    }
}
