package com.woa.bot

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

/** Der Fleet Manager (HTML) in der App. Neue Scan-Ergebnisse werden beim Oeffnen automatisch importiert. */
class FleetActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.webChromeClient = WebChromeClient()          // noetig, damit confirm()-Fenster erscheinen
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val json = Bus.scanJson
                if (json != null) {
                    view.evaluateJavascript("woaImport($json)", null)
                    Bus.scanJson = null
                }
            }
        }
        setContentView(wv)
        wv.loadUrl("file:///android_asset/fleet.html")
    }
}
